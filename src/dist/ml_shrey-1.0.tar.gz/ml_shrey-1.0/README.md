# shreyy

A collection of 9 lab programs by Shreyas, packaged as a Python library.

## Installation

After building the package, install it with:

```bash
pip install dist/shreyy-0.1.0-py3-none-any.whl
```

## Usage

After installation, you can use the lab programs from anywhere:

```python
import shreyy

# Example usage (replace with your actual function names):
shreyy.lab1()
shreyy.lab2()
# ...
```

Each program is available as a function. Check the source for details. 