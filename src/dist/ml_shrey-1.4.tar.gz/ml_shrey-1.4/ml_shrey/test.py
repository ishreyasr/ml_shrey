from ml_shrey.randomforest import randomforest

# Run the Random Forest demo/test function
randomforest()